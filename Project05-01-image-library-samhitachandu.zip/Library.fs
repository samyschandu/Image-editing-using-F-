//
// F# image processing functions.
// In this program, we manipulate PPM format images, such as flip the image horizontally, rotate it to 90 degrees right side, make the picture greyscale, change the image's threshold and zoom the image. 

// Name: Sai Samhita Chandu
// Date of submission: 04.29.2022
// School: University of Illinois at Chicago
//

namespace ImageLibrary

module Operations =
  //
  // all functions must be indented
  //

  //
  // Grayscale:
  //
  // Converts the image into grayscale and returns the 
  // resulting image as a list of lists. Conversion to 
  // grayscale is done by averaging the RGB values for 
  // a pixel, and then replacing them all by that average.
  // So if the RGB values were 25 75 250, the average 
  // would be 116, and then all three RGB values would 
  // become 116 — i.e. 116 116 116.
  //
  // Returns: updated image.
  //
  let rec Grayscale (width:int) 
                    (height:int) 
                    (depth:int) 
                    (image:(int*int*int) list list) = 

    let  GetAverage pixel =
      let (a,b,c) = pixel
      let avg = (a+b+c)/3
      (avg,avg,avg)
      
   
   
    let  SecondList L = 
      List.map(fun e-> GetAverage e) L

    let  FirstList L = 
      List.map(fun e-> SecondList e) L
    
    FirstList image
    

      
    
  //
  // Threshold
  //
  // Thresholding increases image separation --- dark values 
  // become darker and light values become lighter. Given a 
  // threshold value in the range 0 < threshold < color depth,
  // each RGB value is compared to see if it's > threshold.
  // If so, that RGB value is replaced by the color depth;
  // if not, that RGB value is replaced with 0. 
  //
  // Example: if threshold is 100 and depth is 255, then given 
  // a pixel (80, 120, 160), the new pixel is (0, 255, 255).
  //
  // Returns: updated image.
  //

  let rec Threshold (width:int) 
                    (height:int)
                    (depth:int)
                    (image:(int*int*int) list list)
                    (threshold:int) = 

// This function checks if the value is greater than threshold, if yes then we return depth or else we return 0
    let GetThresholdOfValue value = 
      if(value>threshold)= true then
        depth
      else
        0
    // This function simply calls the above function on each r,g,b value
    let GetThreshold pixel =
      let (r,g,b) = pixel
      
      (GetThresholdOfValue r, GetThresholdOfValue g, GetThresholdOfValue b)
      
    // This function helps us go into the r,g,b values of the pixels
    
    let SecondList L = 
      List.map(fun e-> GetThreshold e) L
    
    let  FirstList L = 
      List.map(fun e-> SecondList e) L
    
    // for now, just return the image back, i.e. do nothing:
    FirstList image


  //
  // FlipHorizontal:
  //
  // Flips an image so that what’s on the left is now on 
  // the right, and what’s on the right is now on the left. 
  // That is, the pixel that is on the far left end of the
  // row ends up on the far right of the row, and the pixel
  // on the far right ends up on the far left. This is 
  // repeated as you move inwards toward the row's center.
  //
  // Returns: updated image.
  //
// for this function we just take the whole image and reverse it using .rev
  let rec FlipHorizontal (width:int)
                         (height:int)
                         (depth:int)
                         (image:(int*int*int) list list) = 
    // for now, just return the image back, i.e. do nothing:
    List.map List.rev image
    

    


  //
  // Zoom:
  //
  // Zooms the image by the given zoom factor, which is an 
  // integer 0 < factor < 5. The function uses the nearest 
  // neighbor approach where each pixel P in the original 
  // image is replaced by a factor*factor block of P pixels.
  // For example, if the zoom factor is 4, then each pixel 
  // is replaced by a 4x4 block of 16 identical pixels. 
  // The nearest neighbor algorithm is the simplest zoom 
  // algorithm, but results in jagged images.
  //
  // Returns: updated image.
  //
  let rec Zoom (width:int)
               (height:int)
               (depth:int)
               (image:(int*int*int) list list)
               (factor:int) = 
    

//  here we multiply the pixels by the factor number similarly like how we did for multiplying rows
    let MultiplyPixel L = 
      // List.map(fun pixel-> Helper pixel) L
      let L2 = List.map(fun numpixel -> List.replicate factor numpixel ) L
      let L3 = List.reduce(fun a e -> a @ e)L2
      L3
// We multiply the rows by the factor number and then we use reduce to remove the list inside of the list by adding all the lists
    let  MultiplyRow L = 
      let L2= List.map(fun row-> MultiplyPixel row) L
      let L3 = List.map(fun row-> List.replicate factor row) L2
      List.reduce(fun a e -> a @ e) L3
    
        
    MultiplyRow image


  //
  // RotateRight90:
  //
  // Rotates the image to the right 90 degrees.
  //
  // Returns: updated image.
  //
  let rec RotateRight90 (width:int)
                        (height:int)
                        (depth:int)
                        (image:(int*int*int) list list) = 
    // for now, just return the image back, i.e. do nothing:

    

    // We here first transpose the whole image and then reverse the rows of the transposed list to get the rotate 90 degrees image

    let RotateList L = 
      
      let L2 = List.transpose image
      
      List.map(fun row -> List.rev row)L2
      

    
    RotateList image

// end of project